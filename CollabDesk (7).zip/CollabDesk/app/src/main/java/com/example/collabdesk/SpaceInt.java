package com.example.collabdesk;

import android.util.Log;

public interface SpaceInt {


    public void onSpaceClickListener(int X, int Y);
}
