package com.example.collabdesk;

import java.util.ArrayList;

public interface FireBaseInterface {
    void loadMenu(ArrayList<String> data);
        }
