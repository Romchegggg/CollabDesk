package com.example.collabdesk;

import android.content.Context;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
public class Canvas extends SurfaceView implements SurfaceHolder.Callback {
    public Canvas(Context context) {
        super(context);
        getHolder().addCallback(this);
    }


    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        // создание SurfaceView
    }
    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        // изменение размеров SurfaceView
    }
    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        // уничтожение SurfaceView
    }
}